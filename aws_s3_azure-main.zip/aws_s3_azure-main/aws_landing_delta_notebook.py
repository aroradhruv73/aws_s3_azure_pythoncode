
# This cell is generated from runtime parameters. Learn more: https://go.microsoft.com/fwlink/?linkid=2161015
host = "dlsmfceus2aaihubprd01.dfs.core.windows.net/"
goldcontainer_name = "gold"
gold_path = "aws/snapshot/incremental/delta"
landingcontainer_name = "landing"
ctr_landing_path= "aws/incremental/ltcctr/"
transcript_landing_path= "aws/incremental/ltctranscript/"
source_name = "ltc"


from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, ArrayType
from delta.tables import *
from pyspark.sql.functions import *
import time
from collections import Counter
import json
from datetime import datetime

# Common function to create dataframe for Agent and Caller as contactid is in jobname element in json text
def createAgentCaller_df(df_list_of_jsons):
    json_dict = {}
    for x in df_list_of_jsons:
        b = json.loads(x)
        contact_id = str(b['jobName'])
        #contact_id = contact_id[0:contact_id.find(".")]
        contact_id = contact_id[0:36]
        json_dict[contact_id] = x

    dict_data = list(map(list, json_dict.items()))
    df = spark.createDataFrame(dict_data, ["contactid", "jsondata"])
    return df
    
def readJsonData_From_ADLS(source_name):
    #current_date = '20220315'
    ### Reading CTR json files from folder in landing
    ctr_count = 0
    caller_count = 0
    agent_count = 0
    files_count = 0

    #Create empty DatFrame with no schema (no columns)
    df_joined_tables = spark.createDataFrame([], StructType([]))
    df_agent_transcript = spark.createDataFrame([], StructType([]))
    df_caller_transcript = spark.createDataFrame([], StructType([]))
    
    ctr_adls_path = "abfss://" + landingcontainer_name + "@" + host + ctr_landing_path  + datetime.today().strftime('%Y%m%d') + "/"
    
    # ctr_adls_path = "abfss://landing@dlsmfceus2aaihubprd01.dfs.core.windows.net/aws/incremental/lifectr/20220730/"

    try:
        ctr_files = mssparkutils.fs.ls(ctr_adls_path)
        ctr_count = len(ctr_files)
    except:
        pass

    
    if ctr_count > 0:
        df_ctr = spark.read.json(ctr_adls_path)
        df_list_of_jsons = df_ctr.toJSON().collect()

        json_dict = {}
        for x in df_list_of_jsons:
            b = json.loads(x)
            contact_id = str(b['ContactId'])
            json_dict[contact_id] = x

        dict_data = list(map(list, json_dict.items()))
        df = spark.createDataFrame(dict_data, ["contactid", "jsondata"])
        df.createOrReplaceTempView('ctr_tbl')
    

    ### Reading Agent json files from transcript folder in landing
    
    transcript_adls_path = "abfss://" + landingcontainer_name + "@" + host + transcript_landing_path  + datetime.today().strftime('%Y%m%d') + "/"

    # transcript_adls_path = "abfss://landing@dlsmfceus2aaihubprd01.dfs.core.windows.net/aws/incremental/lifetranscripts/20220730/"
    
    try:
        transcript_files = mssparkutils.fs.ls(transcript_adls_path)
        files_count = len(transcript_files)
    except:
        pass
    
    
    try:
        
        if files_count > 0:
            df_agent = spark.read.json(transcript_adls_path+"*Agent.json")
            if not df_agent.rdd.isEmpty():   #.count() > 0:
                agent_count = 1
                #print('df_agent.count()  :',df_agent.count())
                df_agent_transcript = createAgentCaller_df(df_agent.toJSON().collect())
                df_agent_transcript.createOrReplaceTempView('agent_tbl')
            df_caller = spark.read.json(transcript_adls_path+"*Caller.json")
            if not df_caller.rdd.isEmpty():   #.count() > 0:
                caller_count = 1
                #print('df_agent.count()  :',df_caller.count())
                df_caller_transcript = createAgentCaller_df(df_caller.toJSON().collect())
                df_caller_transcript.createOrReplaceTempView('caller_tbl')    
    except:
        pass
    
    
    ### Joining all the above 3 tables
    #print("Counts ",ctr_count, agent_count , caller_count)
    try:
        if ctr_count > 0 and agent_count > 0 and caller_count > 0:
            #print("IN 1ST IF")
            df_joined_tables = spark.sql('select coalesce(a.contactid,b.contactid,c.contactid) as contactid,a.jsondata as component_ctr,b.jsondata as component_caller,c.jsondata as component_agent,current_timestamp() as load_timestamp from ctr_tbl a full outer join caller_tbl b on a.contactid = b.contactid full outer join agent_tbl c on (a.contactid = c.contactid or b.contactid = c.contactid)')
            #df_joined_tables.printSchema()
        elif ctr_count > 0 and agent_count > 0:
            # print('in second condition')
            df_joined_tables = spark.sql('select coalesce(a.contactid,c.contactid) as contactid,a.jsondata as component_ctr,null as component_caller,c.jsondata as component_agent,current_timestamp() as load_timestamp from ctr_tbl a full outer join agent_tbl c on a.contactid = c.contactid')
        elif ctr_count > 0 and caller_count > 0:
            df_joined_tables = spark.sql('select coalesce(a.contactid,b.contactid) as contactid,a.jsondata as component_ctr,b.jsondata as component_caller,null as component_agent,current_timestamp() as load_timestamp from ctr_tbl a full outer join caller_tbl b on a.contactid = b.contactid')
        elif agent_count > 0 and caller_count > 0:
            # print('agent and caller condition')
            df_joined_tables = spark.sql('select coalesce(b.contactid,c.contactid) as contactid,null as component_ctr,b.jsondata as component_caller,c.jsondata as component_agent,current_timestamp() as load_timestamp from caller_tbl b full outer join agent_tbl c on b.contactid = c.contactid')
        elif ctr_count > 0 and agent_count == 0 and caller_count == 0:
            df_joined_tables = spark.sql('select contactid , jsondata as component_ctr,null as component_caller,null as component_agent,current_timestamp() as load_timestamp from ctr_tbl')

    except:
        pass
    
    
    # print(df_joined_tables.count())   
    # ### Creating delta format files in ADLS 
    # #delta_table_path = "abfss://" + landingcontainer_name + host + landing_path + source_name + "ctr_transcript/delta" + source_name
    #delta_table_path = "abfss://" + goldcontainer_name + host + gold_path + source_name + "_merged/"
    delta_table_path = "abfss://" + goldcontainer_name + "@" + host  + gold_path + "/" + source_name  + "_merged/"
    mssparkutils.fs.mkdirs(delta_table_path)
    files=mssparkutils.fs.ls(delta_table_path)

    ## when agent & caller
    col_dict_caller_agent = {}
    col_dict_caller_agent['t.component_caller'] = 's.component_caller'
    col_dict_caller_agent['t.component_agent'] = 's.component_agent'

    ## when ctr & agent
    col_dict_ctr_agent = {}
    col_dict_ctr_agent['t.component_ctr'] = 's.component_ctr'
    col_dict_ctr_agent['t.component_agent'] = 's.component_agent'

    ## when ctr & caller
    col_dict_ctr_caller = {}
    col_dict_ctr_caller['t.component_ctr'] = 's.component_ctr'
    col_dict_ctr_caller['t.component_agent'] = 's.component_caller'

    ## when only ctr
    col_dict_ctr = {}
    col_dict_ctr['t.component_ctr'] = 's.component_ctr'

    if len(files) == 0 and not df_joined_tables.rdd.isEmpty():    ## for first time
            df_joined_tables.write.format("delta").save(delta_table_path)
    elif not df_joined_tables.rdd.isEmpty() and ctr_count > 0 and agent_count > 0 and caller_count > 0:   ## for ctr, agent and caller
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
    elif not df_joined_tables.rdd.isEmpty() and agent_count > 0 and caller_count > 0:                     ## for agent and caller
        # print('agent and caller delta condition')
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(set = col_dict_caller_agent).whenNotMatchedInsertAll().execute()
    elif not df_joined_tables.rdd.isEmpty() and ctr_count > 0 and agent_count > 0:                        ## for ctr and agent
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(set = col_dict_ctr_agent).whenNotMatchedInsertAll().execute()
    elif not df_joined_tables.rdd.isEmpty() and ctr_count > 0 and caller_count > 0:                       ## for ctr and caller
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(set = col_dict_ctr_caller).whenNotMatchedInsertAll().execute()
    elif not df_joined_tables.rdd.isEmpty() and ctr_count > 0 and agent_count == 0 and caller_count == 0:  ## for ctr only
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(set = col_dict_ctr).whenNotMatchedInsertAll().execute()


readJsonData_From_ADLS(source_name)