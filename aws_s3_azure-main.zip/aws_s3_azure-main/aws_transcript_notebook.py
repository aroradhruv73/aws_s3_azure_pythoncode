host = 'dlsmfceus2aaihubprd01.dfs.core.windows.net'
goldcontainer_name = "gold"
gold_path = "aws/snapshot/incremental/consumption"
landingcontainer_name = "landing"
landing_path= "aws/incremental/"
source_name = "annuity"

from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, ArrayType
from delta.tables import *
from pyspark.sql.functions import *
import time
from collections import Counter
import json
from datetime import datetime

def readJsonData_From_ADLS(source_name):
    #current_date = '20220315'
    ### Reading CTR json files from folder in landing
    ctr_count = 0
    caller_count = 0
    agent_count = 0
    files_count = 0

    #Create empty DatFrame with no schema (no columns)
    df_joined_tables = spark.createDataFrame([], StructType([]))
    #df_agent_transcript = spark.createDataFrame([], StructType([]))
    #df_caller_transcript = spark.createDataFrame([], StructType([]))
    
    ctr_adls_path = "abfss://" + landingcontainer_name + "@" + host + "/" + landing_path  + source_name + 'ctr/' + datetime.today().strftime('%Y%m%d') + "/"
    
    print(ctr_adls_path)
    try:
        ctr_files = mssparkutils.fs.ls(ctr_adls_path)
        ctr_count = len(ctr_files)
    except:
        pass

    
    if ctr_count > 0:
        df_ctr = spark.read.json(ctr_adls_path)
        df_ctr.createOrReplaceTempView('ctr_tbl')

    ### Reading Agent json files from transcript folder in landing
    transcript_adls_path = "abfss://" + landingcontainer_name + "@" + host + "/" + landing_path  + source_name + 'transcript/' + datetime.today().strftime('%Y%m%d') + "/"
    print(transcript_adls_path)
    

    try:
        transcript_files = mssparkutils.fs.ls(transcript_adls_path)
        files_count = len(transcript_files)
    except:
        pass
    
    
    try:
        
        if files_count > 0:
            df_agent = spark.read.json(transcript_adls_path+"*Agent.json")
            if not df_agent.rdd.isEmpty():   #.count() > 0:
                agent_count = 1
                df1_agent = df_agent.select(col("accountid"),substring(col("jobName"),1,36).alias("contactid"),col("results.transcripts.transcript"))
                df1_agent = df1_agent.withColumn("agentTranscript",explode("transcript")).drop("transcript")
                
                df1_agent.createOrReplaceTempView('agent_tbl')

            df_caller = spark.read.json(transcript_adls_path+"*Caller.json")
            if not df_caller.rdd.isEmpty():   #.count() > 0:
                caller_count = 1
                df_caller = spark.read.json(transcript_adls_path+"*Caller.json")
                df1_caller = df_caller.select(col("accountid"),substring(col("jobName"),1,36).alias("contactid"),col("results.transcripts.transcript"))
                df1_caller = df_caller.withColumn("callerTranscript",explode("results.transcripts.transcript")).drop("results.transcripts.transcript")
                df1_caller.createOrReplaceTempView('tmp_tbl')
                df2_caller = spark.sql('select accountId,substring(jobName,1,36) as contactid,callerTranscript from  tmp_tbl' )
                df2_caller.createOrReplaceTempView('caller_tbl')

    except:
        pass
    
    
    ### Joining all the above 3 tables
    
    try:
        if ctr_count > 0 and agent_count > 0 and caller_count > 0:
            df_joined_tables = spark.sql('select coalesce(a.accountId,b.accountId) as accountid,coalesce(a.contactid,b.contactid,c.ContactId) as contactid, a.agenttranscript,b.callertranscript,c.connectedtosystemtimestamp from agent_tbl a full outer join caller_tbl b on a.contactid = b.contactid full outer join ctr_tbl c on (a.contactid = c.ContactId or b.contactid = c.ContactId)')
        elif ctr_count > 0 and agent_count > 0:
            df_joined_tables = spark.sql('select c.accountId as accountid,coalesce(a.ContactId,c.contactid) as contactid,c.agenttranscript,null as callertranscript,a.connectedtosystemtimestamp from ctr_tbl a full outer join agent_tbl c on a.ContactId = c.contactid')
        elif ctr_count > 0 and caller_count > 0:
            df_joined_tables = spark.sql('select b.accountId as accountid,coalesce(a.ContactId,b.contactid) as contactid,null as agenttranscript,b.callertranscript,a.connectedtosystemtimestamp,from ctr_tbl a full outer join caller_tbl b on a.contactid = b.contactid')
        elif agent_count > 0 and caller_count > 0:
            df_joined_tables = spark.sql('select coalesce(b.accountId,c.accountId) as accountid,coalesce(b.contactid,c.contactid) as contactid,c.agenttranscript,b.callertranscript,null as connectedtosystemtimestamp from caller_tbl b full outer join agent_tbl c on b.contactid = c.contactid')
        elif ctr_count > 0 and agent_count == 0 and caller_count == 0:
            df_joined_tables = spark.sql('select null as accountid,a.contactid,null as agenttranscript,null as callertranscript,a.connectedtosystemtimestamp from ctr_tbl a')
        elif agent_count > 0 and caller_count == 0 and ctr_count == 0:
            df_joined_tables = spark.sql('select c.accountId as accountid,c.contactid as contactid,c.agenttranscript,null as callertranscript,null as connectedtosystemtimestamp from agent_tbl c')
        elif agent_count == 0 and caller_count > 0 and ctr_count == 0:
            df_joined_tables = spark.sql('select b.accountId as accountid,b.contactid as contactid,null as agenttranscript,b.callertranscript,null as connectedtosystemtimestamp from caller_tbl b')

    except:
        pass

    delta_table_path = "abfss://" + goldcontainer_name + '@' + host + "/"  + gold_path + "/" + source_name  + "_transcripts/"
    print(delta_table_path)
    mssparkutils.fs.mkdirs(delta_table_path)
    files=mssparkutils.fs.ls(delta_table_path)

    ## when agent & caller
    col_dict_caller_agent = {}
    col_dict_caller_agent['t.accountId'] = 's.accountId'
    col_dict_caller_agent['t.agenttranscript'] = 's.agenttranscript'
    col_dict_caller_agent['t.callertranscript'] = 's.callertranscript'

    ## when ctr & agent
    col_dict_ctr_agent = {}
    col_dict_ctr_agent['t.accountId'] = 's.accountId'
    col_dict_ctr_agent['t.agenttranscript'] = 's.agenttranscript'
    col_dict_ctr_agent['t.connectedtosystemtimestamp'] = 's.connectedtosystemtimestamp'

    ## when ctr & caller
    col_dict_ctr_caller = {}
    col_dict_ctr_caller['t.accountId'] = 's.accountId'
    col_dict_ctr_caller['t.callertranscript'] = 's.callertranscript'
    col_dict_ctr_caller['t.connectedtosystemtimestamp'] = 's.connectedtosystemtimestamp'

    ## when only ctr
    col_dict_ctr = {}
    col_dict_ctr['t.connectedtosystemtimestamp'] = 's.connectedtosystemtimestamp'
    
    
    if len(files) == 0 and not df_joined_tables.rdd.isEmpty():    ## for first time
            df_joined_tables.write.format("delta").save(delta_table_path)
    elif not df_joined_tables.rdd.isEmpty() and ctr_count > 0 and agent_count > 0 and caller_count > 0:   ## for ctr, agent and caller
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(
            condition = "t.callertranscript is null AND t.contactid is not null AND s.callertranscript is not null",
            set = {"t.callertranscript" : "s.callertranscript","t.accountId": "s.accountId"}
        ).whenNotMatchedInsertAll().execute()

        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(
            condition = "t.agenttranscript is null AND t.contactid is not null AND s.agenttranscript is not null",
            set = {"t.agenttranscript" : "s.agenttranscript","t.accountId": "s.accountId"}
        ).execute()

        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(
            condition = "t.contactid is not null AND s.connectedtosystemtimestamp is not null",
            set = {"t.connectedtosystemtimestamp" : "s.connectedtosystemtimestamp"}
        ).execute()

        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(
            condition = "t.contactid is not null AND (t.agenttranscript is null AND t.callertranscript is null) and (s.agenttranscript is not null AND s.callertranscript is not null)",
            set = {"t.connectedtosystemtimestamp" : "s.connectedtosystemtimestamp","t.agenttranscript" : "s.agenttranscript","t.callertranscript" : "s.callertranscript","t.accountId": "s.accountId"}
        ).execute()
    elif not df_joined_tables.rdd.isEmpty() and agent_count > 0 and caller_count > 0:                     ## for agent and caller
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(set = col_dict_caller_agent).whenNotMatchedInsertAll().execute()
    elif not df_joined_tables.rdd.isEmpty() and ctr_count > 0 and agent_count > 0:                        ## for ctr and agent
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(set = col_dict_ctr_agent).whenNotMatchedInsertAll().execute()
    elif not df_joined_tables.rdd.isEmpty() and ctr_count > 0 and caller_count > 0:                       ## for ctr and caller
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(set = col_dict_ctr_caller).whenNotMatchedInsertAll().execute()
    elif not df_joined_tables.rdd.isEmpty() and ctr_count > 0 and agent_count == 0 and caller_count == 0:  ## for ctr only
        deltaTable = DeltaTable.forPath(spark, delta_table_path)
        deltaTable.alias("t").merge(
            df_joined_tables.alias("s"),
            "s.contactid = t.contactid"
        ).whenMatchedUpdate(set = col_dict_ctr).whenNotMatchedInsertAll().execute()
    
readJsonData_From_ADLS(source_name)